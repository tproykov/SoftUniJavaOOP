package carShopExtended;

public interface Sellable {

    Double getPrice();
    String sellInfo();
}