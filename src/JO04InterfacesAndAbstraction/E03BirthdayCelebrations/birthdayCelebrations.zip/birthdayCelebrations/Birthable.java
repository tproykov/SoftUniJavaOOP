package birthdayCelebrations;

public interface Birthable {

    String getBirthDay();
}