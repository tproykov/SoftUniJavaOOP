package JO04InterfacesAndAbstraction.E06MilitaryElite;

public interface Spy extends Soldier {

    String getCodeNumber();
}