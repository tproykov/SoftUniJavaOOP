package multipleImplementations;

public interface Birthable {

    String getBirthDate();
}