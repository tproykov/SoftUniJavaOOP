package militaryElite;

public interface SpecialisedSoldier extends Private {

    String getCorps();
}