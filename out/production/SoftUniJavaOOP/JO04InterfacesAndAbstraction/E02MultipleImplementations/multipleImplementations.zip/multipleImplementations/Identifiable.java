package multipleImplementations;

public interface Identifiable {

    String getId();
}