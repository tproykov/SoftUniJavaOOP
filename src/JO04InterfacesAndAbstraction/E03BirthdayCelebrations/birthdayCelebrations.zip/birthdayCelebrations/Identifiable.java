package birthdayCelebrations;

public interface Identifiable {

    String getId();
}