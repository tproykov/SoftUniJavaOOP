package borderControl;

public interface Identifiable {

    public String getId();
}