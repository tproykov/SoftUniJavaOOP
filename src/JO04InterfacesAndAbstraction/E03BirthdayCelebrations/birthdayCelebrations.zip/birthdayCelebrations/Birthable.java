package birthdayCelebrations;

public interface Birthable {

    String getBirthDate();
}